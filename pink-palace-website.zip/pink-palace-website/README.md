# Pink Palace — Restaurant Website

A responsive React + TypeScript + Vite website for Pink Palace, Mudalagi.

## Run locally

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

## Deploy to Vercel

1. Push this folder to a GitHub repository.
2. Import the repository in Vercel.
3. Framework preset: Vite.
4. Build command: `npm run build`.
5. Output directory: `dist`.

## Important launch checklist

- Replace the illustrative Unsplash image URLs in `src/data.ts` and `src/App.tsx` with Pink Palace's actual photographs.
- Verify the restaurant's Google Maps pin and replace the search-area embed if a verified place URL becomes available.
- Confirm the phone and WhatsApp number with the owner.
- Confirm all opening hours and listed amenities with the owner before publishing.
- Add the official Instagram URL when supplied.
- Add a canonical domain and sitemap/robots files once the production domain is known.

## Current enquiry behaviour

The table enquiry form validates the fields and opens WhatsApp with the customer's details. It does not create or confirm a reservation. The restaurant must respond directly.

## Data accuracy

No menu prices or unverified dishes are listed. Menu cards are category-level discovery items and explicitly direct customers to confirm today's availability and pricing.
