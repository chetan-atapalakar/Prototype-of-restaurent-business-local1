import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowDown, ArrowRight, ArrowUpRight, Check, Clock3, Compass, Leaf,
  MapPin, Menu as MenuIcon, Phone, Sparkles, Users, Utensils, X,
  CarFront, CreditCard, Baby, Instagram, MessageCircle
} from "lucide-react";
import { gallery, hours, menuCategories, menuItems, restaurant } from "./data";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } }
};

function useOpenStatus() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 30_000);
    return () => window.clearInterval(timer);
  }, []);
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata", weekday: "long", hour: "2-digit", minute: "2-digit", hourCycle: "h23"
  }).formatToParts(now);
  const day = parts.find(p => p.type === "weekday")?.value ?? "Monday";
  const hour = Number(parts.find(p => p.type === "hour")?.value ?? 0);
  const minute = Number(parts.find(p => p.type === "minute")?.value ?? 0);
  const today = hours.find(h => h.day === day)!;
  const current = hour * 60 + minute;
  const opening = Number(today.open.slice(0, 2)) * 60 + Number(today.open.slice(3));
  const closing = Number(today.close.slice(0, 2)) * 60 + Number(today.close.slice(3));
  return { day, isOpen: current >= opening && current < closing, today };
}

function SectionHeading({ eyebrow, title, text }: { eyebrow: string; title: string; text?: string }) {
  return <motion.div className="section-heading" variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.25 }}>
    <span className="eyebrow"><span />{eyebrow}</span>
    <h2>{title}</h2>
    {text && <p>{text}</p>}
  </motion.div>;
}

function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [category, setCategory] = useState("all");
  const [lightbox, setLightbox] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", phone: "", date: "", time: "", guests: "2" });
  const [formError, setFormError] = useState("");
  const { day, isOpen, today } = useOpenStatus();
  const reduceMotion = useReducedMotion();

  const filteredItems = useMemo(() => category === "all" ? menuItems : menuItems.filter(item => item.category === category), [category]);
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(restaurant.mapQuery)}`;
  const whatsappUrl = `https://wa.me/${restaurant.phoneRaw}?text=${encodeURIComponent("Hello Pink Palace, I would like to enquire about visiting the restaurant.")}`;

  useEffect(() => {
    document.body.style.overflow = lightbox !== null ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [lightbox]);

  const closeMobile = () => setMobileOpen(false);
  const submitEnquiry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !/^[0-9+\-\s]{8,15}$/.test(form.phone.trim()) || !form.date || !form.time) {
      setFormError("Please complete your name, valid contact number, date and preferred time.");
      return;
    }
    setFormError("");
    const message = `Hello Pink Palace, I would like to make a table enquiry.%0AName: ${encodeURIComponent(form.name)}%0AContact: ${encodeURIComponent(form.phone)}%0APreferred date: ${encodeURIComponent(form.date)}%0APreferred time: ${encodeURIComponent(form.time)}%0AGuests: ${encodeURIComponent(form.guests)}%0A%0AI understand this is an enquiry and is subject to restaurant confirmation.`;
    window.open(`https://wa.me/${restaurant.phoneRaw}?text=${message}`, "_blank", "noopener,noreferrer");
  };

  const navLinks = [
    ["About", "#about"], ["Menu", "#menu"], ["Gallery", "#gallery"],
    ["Experience", "#experience"], ["Visit", "#visit"]
  ];

  return <div className="site-shell">
    <div className="announcement"><Leaf size={13} /> PURE VEGETARIAN HOSPITALITY <span className="announcement-dot">✦</span> MUDALAGI, KARNATAKA</div>

    <header className="site-header">
      <a className="brand" href="#home" aria-label="Pink Palace home" onClick={closeMobile}>
        <span className="brand-mark">✿</span>
        <span><strong>PINK PALACE</strong><small>VEGETARIAN FAMILY RESTAURANT</small></span>
      </a>
      <nav className="desktop-nav" aria-label="Main navigation">
        {navLinks.map(([label, href]) => <a key={href} href={href}>{label}</a>)}
      </nav>
      <a className="header-cta" href={mapsUrl} target="_blank" rel="noreferrer">Find us <ArrowUpRight size={15} /></a>
      <button className="mobile-menu-button" aria-label={mobileOpen ? "Close menu" : "Open menu"} aria-expanded={mobileOpen} onClick={() => setMobileOpen(v => !v)}>
        {mobileOpen ? <X /> : <MenuIcon />}
      </button>
    </header>

    <AnimatePresence>
      {mobileOpen && <motion.nav className="mobile-nav" initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} aria-label="Mobile navigation">
        {navLinks.map(([label, href]) => <a key={href} href={href} onClick={closeMobile}>{label}<ArrowUpRight size={16} /></a>)}
        <a href={`tel:${restaurant.phone}`} onClick={closeMobile}>Call the restaurant <Phone size={16} /></a>
      </motion.nav>}
    </AnimatePresence>

    <main>
      <section className="hero" id="home">
        <div className="hero-image" />
        <div className="hero-shade" />
        <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
        <div className="hero-content">
          <motion.div initial="hidden" animate="visible" variants={{ visible: { transition: { staggerChildren: 0.13 } } }}>
            <motion.div className="hero-kicker" variants={fadeUp}><span className="kicker-line" /> A NEW TABLE IN MUDALAGI <span className="kicker-line" /></motion.div>
            <motion.h1 variants={fadeUp}>Where Every Meal<br /><em>Feels Like a</em><br />Celebration.</motion.h1>
            <motion.p variants={fadeUp}>Discover delightful vegetarian flavours, comforting meals and memorable moments at Pink Palace.</motion.p>
            <motion.div className="hero-actions" variants={fadeUp}>
              <a className="button button-dark" href="#menu">Explore our menu <ArrowRight size={16} /></a>
              <a className="button button-glass" href="#visit"><MapPin size={16} /> Visit Pink Palace</a>
            </motion.div>
          </motion.div>
        </div>
        <div className="hero-bottom">
          <div className="pure-badge"><span><Leaf size={16} /></span><div><b>100% Vegetarian</b><small>Goodness in every visit</small></div></div>
          <div className="hero-location"><MapPin size={15} /> Gokak Road, Mudalagi</div>
          <a href="#about" className="scroll-cue">SCROLL TO DISCOVER <ArrowDown size={14} /></a>
        </div>
        <div className="hero-index">01 <span /> 05</div>
      </section>

      <section className="intro-section section-pad" id="about">
        <div className="intro-side-note">A PLACE TO<br />COME TOGETHER</div>
        <div className="intro-grid">
          <motion.div className="intro-visual" initial={{ opacity: 0, x: -28 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: .8 }}>
            <img src="https://images.unsplash.com/photo-1512621776951-a57141f2e6a2?auto=format&fit=crop&w=1200&q=88" alt="A colourful vegetarian meal" loading="lazy" />
            <div className="image-stamp"><span>✿</span><b>Made for<br />good moments</b></div>
            <div className="image-caption">THE PINK PALACE EXPERIENCE <span>✦</span></div>
          </motion.div>
          <div className="intro-copy">
            <SectionHeading eyebrow="A LITTLE TASTE OF HAPPINESS" title="Good food. Better company." />
            <p className="body-large">Pink Palace is a casual, recently opened vegetarian family restaurant on Gokak Road near the TVS Showroom in Mudalagi.</p>
            <p>Designed for families, friends and solo diners, it brings together delicious vegetarian food and a relaxed, contemporary dining atmosphere.</p>
            <a className="text-link" href="#experience">Discover the experience <ArrowUpRight size={16} /></a>
            <div className="intro-stats">
              <div><strong>100%</strong><span>Vegetarian</span></div>
              <div><strong>♡</strong><span>Family friendly</span></div>
              <div><strong>✦</strong><span>Group-friendly</span></div>
            </div>
          </div>
        </div>
      </section>

      <section className="menu-section section-pad" id="menu">
        <div className="menu-top">
          <SectionHeading eyebrow="FRESH FROM OUR KITCHEN" title="A menu worth gathering for." text="A little something for every appetite. Ask our team about today's available dishes and pricing." />
          <div className="menu-note"><span className="veg-symbol">●</span> Vegetarian menu<br /><small>Availability may vary each day.</small></div>
        </div>
        <div className="menu-tabs" role="tablist" aria-label="Menu categories">
          <button className={category === "all" ? "active" : ""} onClick={() => setCategory("all")} role="tab" aria-selected={category === "all"}>All</button>
          {menuCategories.map(c => <button key={c.id} className={category === c.id ? "active" : ""} onClick={() => setCategory(c.id)} role="tab" aria-selected={category === c.id}>{c.name}</button>)}
        </div>
        <motion.div className="menu-grid" layout>
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item, i) => <motion.article className="menu-card" key={item.id} layout initial={reduceMotion ? false : { opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: .97 }} transition={{ duration: .35, delay: i * .035 }}>
              <div className="menu-card-image"><img src={item.image} alt={item.name} loading="lazy" /><span className="veg-dot" title="Vegetarian" /></div>
              <div className="menu-card-copy"><div><span className="menu-label">PINK PALACE MENU</span><h3>{item.name}</h3><p>{item.note}</p></div><a href={whatsappUrl} target="_blank" rel="noreferrer" aria-label={`Ask about ${item.name}`}><ArrowUpRight size={18} /></a></div>
            </motion.article>)}
          </AnimatePresence>
        </motion.div>
        <div className="menu-footer"><span>Today's menu and pricing may vary.</span><a href={whatsappUrl} target="_blank" rel="noreferrer" className="text-link">Ask us about the menu <ArrowUpRight size={16} /></a></div>
      </section>

      <section className="gallery-section section-pad" id="gallery">
        <div className="gallery-heading"><SectionHeading eyebrow="A FEAST FOR THE EYES" title="Moments, served beautifully." text="A glimpse of the flavours and moments that make dining special." /><span className="gallery-aside">THE ART OF<br />SLOWING DOWN <span>✳</span></span></div>
        <div className="gallery-grid">
          {gallery.map((img, i) => <button key={img.src} className={`gallery-tile ${img.shape}`} onClick={() => setLightbox(i)} aria-label={`Expand image: ${img.alt}`}>
            <img src={img.src} alt={img.alt} loading="lazy" /><span className="gallery-expand"><ArrowUpRight size={19} /></span>
          </button>)}
        </div>
        <p className="gallery-disclaimer">Gallery imagery is illustrative and will be replaced with Pink Palace's actual restaurant photographs before launch.</p>
      </section>

      <section className="experience-section section-pad" id="experience">
        <div className="experience-top"><SectionHeading eyebrow="MORE THAN A MEAL" title="Make room for togetherness." text="A relaxed, contemporary setting for the people and moments that matter." /><div className="experience-flower">✿</div></div>
        <div className="experience-grid">
          {[
            { icon: <Users />, number: "01", title: "Family Dining", text: "A welcoming place for family gatherings and shared meals." },
            { icon: <Utensils />, number: "02", title: "Group Meals", text: "Enjoy casual meals and catch-ups with friends and groups." },
            { icon: <Sparkles />, number: "03", title: "Solo Dining", text: "A relaxed atmosphere for a little time to yourself." },
            { icon: <Compass />, number: "04", title: "Casual Experience", text: "Trendy surroundings for everyday dining and easy moments." }
          ].map(item => <motion.article className="experience-card" key={item.number} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <div className="experience-card-head"><span>{item.number}</span><div>{item.icon}</div></div>
            <h3>{item.title}</h3><p>{item.text}</p><span className="card-spark">✳</span>
          </motion.article>)}
        </div>
      </section>

      <section className="visit-section section-pad" id="visit">
        <div className="visit-grid">
          <div className="visit-copy">
            <SectionHeading eyebrow="YOUR TABLE IS WAITING" title="Find your way to Pink Palace." text="Come by for a relaxed vegetarian meal on Gokak Road, Mudalagi." />
            <div className="address-line"><span className="detail-icon"><MapPin /></span><div><b>Find us</b><p>{restaurant.address}</p></div></div>
            <div className="address-line"><span className="detail-icon"><Phone /></span><div><b>Call the restaurant</b><a href={`tel:${restaurant.phone}`}>{restaurant.phone}</a></div></div>
            <div className="visit-actions">
              <a className="button button-dark" href={mapsUrl} target="_blank" rel="noreferrer">Get directions <ArrowUpRight size={16} /></a>
              <a className="button button-outline" href={whatsappUrl} target="_blank" rel="noreferrer"><MessageCircle size={16} /> WhatsApp us</a>
            </div>
          </div>
          <div className="map-wrap">
            <iframe title="Map showing the Pink Palace search area in Mudalagi" src={`https://www.google.com/maps?q=${encodeURIComponent(restaurant.mapQuery)}&output=embed`} loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
            <div className="map-caption"><MapPin size={15} /><span>Gokak Road · Mudalagi</span><a href={mapsUrl} target="_blank" rel="noreferrer">Open map <ArrowUpRight size={14} /></a></div>
          </div>
        </div>
      </section>

      <section className="hours-section section-pad" id="hours">
        <div className="hours-card">
          <div className="hours-intro"><span className="eyebrow"><span /> PLAN YOUR VISIT</span><h2>Good times<br /><em>have a schedule.</em></h2><p>We look forward to welcoming you.</p>
            <div className={`open-status ${isOpen ? "is-open" : "is-closed"}`}><span className="status-dot" />{isOpen ? "Open now" : "Currently closed"} <small>· India Standard Time</small></div>
          </div>
          <div className="hours-list">
            <div className="hours-list-heading"><span>OPENING HOURS</span><Clock3 size={17} /></div>
            {hours.map(h => <div className={`hours-row ${h.day === day ? "today" : ""}`} key={h.day}><span>{h.day}{h.day === day && <small> TODAY</small>}</span><b>{h.label}</b>{h.day === day && <Check size={15} />}</div>)}
            <p className="hours-footnote">Hours are displayed in Indian Standard Time (IST).</p>
          </div>
        </div>
      </section>

      <section className="amenities-section section-pad">
        <SectionHeading eyebrow="THE LITTLE DETAILS" title="Everything for an easy visit." />
        <div className="amenities-grid">
          {[
            [<Utensils />, "Dine-in service"], [<CarFront />, "Free parking lot"], [<MapPin />, "Free street parking"],
            [<CreditCard />, "NFC mobile payments"], [<Leaf />, "Vegetarian restaurant"], [<Baby />, "Suitable for children"],
            [<Users />, "Group-friendly dining"]
          ].map(([icon, label]) => <div className="amenity" key={label as string}><span>{icon}</span><b>{label as string}</b><Check size={14} /></div>)}
        </div>
      </section>

      <section className="enquiry-section section-pad" id="enquiry">
        <div className="enquiry-inner">
          <div><span className="eyebrow"><span /> LET'S PLAN A VISIT</span><h2>Something to<br /><em>look forward to.</em></h2><p>Send a table enquiry and the restaurant team can confirm availability with you directly.</p><div className="enquiry-note"><Check size={15} /> This is an enquiry, not a confirmed reservation.</div></div>
          <form className="enquiry-form" onSubmit={submitEnquiry}>
            <div className="form-heading"><b>Table enquiry</b><span>We'll pass your request to the restaurant.</span></div>
            <label>Your name<input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Enter your name" autoComplete="name" required /></label>
            <label>Contact number<input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="+91 ..." inputMode="tel" autoComplete="tel" required /></label>
            <div className="form-row">
              <label>Preferred date<input type="date" min={new Date().toLocaleDateString("en-CA")} value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required /></label>
              <label>Preferred time<input type="time" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} required /></label>
            </div>
            <label>Number of guests<select value={form.guests} onChange={e => setForm({ ...form, guests: e.target.value })}>{["1","2","3","4","5","6","7","8","9","10","10+"].map(n => <option key={n} value={n}>{n} {n === "1" ? "guest" : "guests"}</option>)}</select></label>
            {formError && <p className="form-error" role="alert">{formError}</p>}
            <button className="button button-dark form-submit" type="submit">Send enquiry on WhatsApp <ArrowUpRight size={16} /></button>
            <small className="form-privacy">Your message opens in WhatsApp. Pink Palace must confirm any reservation directly.</small>
          </form>
        </div>
      </section>

      <section className="closing-banner">
        <div className="closing-flower">✿</div><span>THE PINK PALACE PROMISE</span><h2>Good Food. Beautiful Moments.</h2><p>We can't wait to welcome you.</p><a href="#visit" className="button button-light">Plan your visit <ArrowRight size={16} /></a>
      </section>
    </main>

    <footer className="footer">
      <div className="footer-main">
        <div className="footer-brand"><a className="brand footer-logo" href="#home"><span className="brand-mark">✿</span><span><strong>PINK PALACE</strong><small>VEGETARIAN FAMILY RESTAURANT</small></span></a><p>A casual vegetarian dining destination for families, friends and beautiful everyday moments in Mudalagi.</p><div className="footer-social"><a href={whatsappUrl} target="_blank" rel="noreferrer" aria-label="WhatsApp"><MessageCircle /></a><a href="#visit" aria-label="Location"><MapPin /></a><a href="#home" aria-label="Instagram account not yet provided"><Instagram /></a></div></div>
        <div className="footer-links"><b>EXPLORE</b>{navLinks.map(([label, href]) => <a key={href} href={href}>{label}</a>)}</div>
        <div className="footer-links"><b>VISIT US</b><span>{restaurant.address}</span><a href={`tel:${restaurant.phone}`}>{restaurant.phone}</a><a href="#hours">Opening hours</a></div>
      </div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} Pink Palace. All rights reserved.</span><span>GOOD FOOD. BEAUTIFUL MOMENTS. PINK PALACE.</span><a href="#home">Back to top ↑</a></div>
    </footer>

    <div className="mobile-contact-bar"><a href={`tel:${restaurant.phone}`}><Phone size={17} /> Call</a><a href={mapsUrl} target="_blank" rel="noreferrer"><MapPin size={17} /> Directions</a></div>

    <AnimatePresence>
      {lightbox !== null && <motion.div className="lightbox" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setLightbox(null)} role="dialog" aria-modal="true" aria-label="Gallery image viewer">
        <button className="lightbox-close" onClick={() => setLightbox(null)} aria-label="Close gallery"><X /></button>
        <button className="lightbox-prev" onClick={e => { e.stopPropagation(); setLightbox((lightbox + gallery.length - 1) % gallery.length); }} aria-label="Previous image">‹</button>
        <motion.img key={lightbox} src={gallery[lightbox].src} alt={gallery[lightbox].alt} initial={{ scale: .96, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} onClick={e => e.stopPropagation()} />
        <button className="lightbox-next" onClick={e => { e.stopPropagation(); setLightbox((lightbox + 1) % gallery.length); }} aria-label="Next image">›</button>
        <span className="lightbox-count">{lightbox + 1} / {gallery.length}</span>
      </motion.div>}
    </AnimatePresence>
  </div>;
}

export default App;
